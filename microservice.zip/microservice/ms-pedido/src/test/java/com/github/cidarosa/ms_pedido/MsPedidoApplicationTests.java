package com.github.cidarosa.ms_pedido;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsPedidoApplicationTests {

	@Test
	void contextLoads() {
	}

}
