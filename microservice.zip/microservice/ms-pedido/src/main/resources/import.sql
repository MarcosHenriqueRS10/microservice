INSERT INTO tb_pedido (nome, cpf, data, status) VALUES('Jon Snow', '12345678965', '2025-04-28', 'REALIZADO');
INSERT INTO tb_item_do_pedido(quantidade, descricao, valor_unitario, pedido_id) VALUES(2, 'Mouse sem fio Microsoft', 250.0, 1)
INSERT INTO tb_item_do_pedido(quantidade, descricao, valor_unitario, pedido_id) VALUES(1, 'Teclado sem fio Microsoft', 290.0, 1)


INSERT INTO tb_pedido (nome, cpf, data, status) VALUES('Ayra Stark', '36547865432', '2025-04-28', 'REALIZADO');
INSERT INTO tb_item_do_pedido(quantidade, descricao, valor_unitario, pedido_id) VALUES(1, 'Smart TV LEG LED', 3599.0, 2)
