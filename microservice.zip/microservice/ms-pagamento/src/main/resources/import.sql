INSERT INTO tb_pagamento(valor, nome, numero_do_cartao, validade, codigo_de_seguranca, status, pedido_id, forma_de_pagamento_id) VALUES(35.55, 'Amadeus Mozart', '6895426578961254', '12/30', '589', 'CRIADO', 5, 2);
INSERT INTO tb_pagamento(valor, nome, numero_do_cartao, validade, codigo_de_seguranca, status, pedido_id, forma_de_pagamento_id) VALUES(95.50, 'Chiquinha Gonzaga', '2457896547123654', '01/28', '389', 'CRIADO', 3, 2);
INSERT INTO tb_pagamento(valor, nome, numero_do_cartao, validade, codigo_de_seguranca, status, pedido_id, forma_de_pagamento_id) VALUES(128.0, 'Ludwig van Beethoven', '2456178921437892', '07/32', '379', 'CRIADO', 15, 2);

INSERT INTO tb_pagamento(valor,  status, pedido_id, forma_de_pagamento_id) VALUES(1200, 'CRIADO', 4, 1);
INSERT INTO tb_pagamento(valor,  status, pedido_id, forma_de_pagamento_id) VALUES(1200, 'CANCELADO', 4, 1);
INSERT INTO tb_pagamento(valor,  status, pedido_id, forma_de_pagamento_id) VALUES(125.25, 'CONFIRMADO', 6, 1);